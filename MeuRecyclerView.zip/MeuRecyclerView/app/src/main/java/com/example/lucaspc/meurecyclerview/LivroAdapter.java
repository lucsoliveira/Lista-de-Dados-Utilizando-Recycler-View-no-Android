package com.example.lucaspc.meurecyclerview;

/* dependencias para o adapter e o recycler*/
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.List;
/* dependencias para o adapter e o recycler*/

/**
 * Created by lucaspc on 02/02/18.
 * Quinto passo: criar o adapter do tipo desejado, nesse caso o nosso adapter é o de livros
 * ou seja, um adapter de uma lista de livros
 */

public class LivroAdapter extends RecyclerView.Adapter {

    private List<Livro> livros;
    private Context context;

    public LivroAdapter(List<Livro> livros, Context context) {
        this.livros = livros;
        this.context = context;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                      int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_livro, parent, false);
        LivroViewHolder holder = new LivroViewHolder(view);

        return holder;
    }



    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder,
                                 int position) {
        LivroViewHolder holder = (LivroViewHolder) viewHolder;
        Livro livro  = livros.get(position) ;
        holder.nome.setText(livro.getNomeLivro());
        holder.autor.setText(livro.getNomeAutor());
        holder.descricao.setText(livro.getDescricao());
        holder.preco.setText(Double.toString(livro.getPreco()));
    }

    @Override
    public int getItemCount() {
        return livros.size();
    }
}