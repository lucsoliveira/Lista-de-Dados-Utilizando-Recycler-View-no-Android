package com.example.lucaspc.meurecyclerview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;//não se esqueca que o recycler precisa importar essa biblioteca

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //terceiro passo: Pegar a referencia do Recycler View aqui no método onCreate
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycler);

        //sexto passo: Implementar o adapter criado e recuperar uma lista do tipo desejado
        List<Livro> livros = new ArrayList<Livro>();

        /* ACRESCENTA LIVROS NA LISTA */
        Livro livrinho = new Livro("O Jardim das Aflições","Carvalho, Olavo de", "Ótimo Livro", 40.00);
        livros.add(livrinho);

        livrinho = new Livro("1984","Orwell, George", "Ótimo Livro", 28.90);
        livros.add(livrinho);

        livrinho = new Livro("Admirável Mundo Novo","Orwell, George", "Ótimo Livro", 19.90);
        livros.add(livrinho);

        livrinho = new Livro("O Sol É Para Todos","Lee, Harper", "Ótimo Livro", 19.90);
        livros.add(livrinho);

        livrinho = new Livro("Como Ler Livros","Huxley, Aldous", "Ótimo Livro", 50.00);
        livros.add(livrinho);

        livrinho = new Livro("A Revolução Dos Bichos","Orwell, George", "Ótimo Livro", 19.90);
        livros.add(livrinho);

        /* ACRESCENTA LIVROS NA LISTA */

        recyclerView.setAdapter(new LivroAdapter(livros, this));

        RecyclerView.LayoutManager layout = new LinearLayoutManager(this,
                LinearLayoutManager.VERTICAL, false);

        recyclerView.setLayoutManager(layout);

    }
}
