package com.example.lucaspc.meurecyclerview;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

/**
 * Created by lucaspc on 02/02/18.
 * Sétimo passo: implementado o view Holder
 */

public class LivroViewHolder extends RecyclerView.ViewHolder {

    final TextView nome;
    final TextView descricao;
    final TextView preco;
    final TextView autor;

    public LivroViewHolder(View view) {
        super(view);
        nome = (TextView) view.findViewById(R.id.item_livro_nome);
        descricao = (TextView) view.findViewById(R.id.item_livro_desc);
        autor = (TextView) view.findViewById(R.id.item_livro_autor);
        preco = (TextView) view.findViewById(R.id.item_livro_preco);
    }
}
